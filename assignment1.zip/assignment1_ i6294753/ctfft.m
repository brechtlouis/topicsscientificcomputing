function freq = ctfft(sample)
% Cooley-Tuckey recursive implementation of the FFT algorithm
%
% input
%   x : discrete input signal
% output
%   y  : frequency domain representation

    if size(sample, 2) > 1
        for i = 1 : size(sample, 2)
            freq(:, i) = ctfft(sample(:, i));
        end
    else

        numsamples = numel(sample);

        if numsamples > 1
            % recursively compute FFT

            % even positions
            evenValues = ctfft(sample(1:2:numsamples));
            % odd positions
            oddValues  = ctfft(sample(2:2:numsamples));

            % common part
            weights = exp(-2i * pi * (0:numsamples/2 - 1)/numsamples); 

            % FTT left side
            leftSide  = evenValues + weights .* oddValues;
            % FTT right side
            rightSide = evenValues - weights .* oddValues;

            % combine both sides
            freq = [leftSide rightSide];
        else
            % single value, no more recursion
            freq = sample;
        end
    end
end
