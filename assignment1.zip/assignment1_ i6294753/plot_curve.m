function plot_curve(x, y, title_str, x_str, y_str, symbol)
% Plots a curve given by x and y values, plus title, axis labels, and special symbol

    % check if argument has been passed before displaying it
    if exist('symbol', 'var')
        plot(x, y, symbol);
    else
        plot(x, y);
    end
    axis([x(1), x(end), min(y), max(y)])
 
    if exist('title_str', 'var')
        title(title_str);
    end
 
    if exist('x_str', 'var')
        xlabel(x_str);
    end
 
    if exist('y_str', 'var')
        ylabel(y_str);
    end
end