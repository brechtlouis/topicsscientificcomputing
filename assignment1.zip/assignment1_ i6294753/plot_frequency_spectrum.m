function plot_frequency_spectrum (a, b, function_name, T)

    % amplitudes
    A = sqrt(a.^2 + b.^2);
    n = length(A);
    % frequencies
    x = (0:n - 1) / T;

    plot_curve(x, A, function_name, 'frequency (Hz)', 'amplitude')
    axis([x(1), x(end), 0, 1])

end
