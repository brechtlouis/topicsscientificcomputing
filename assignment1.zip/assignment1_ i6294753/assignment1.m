clear all

% closes all figures
close all


% TEST FUNCTIONS

% cell-arrays store function name and definition, a vector stores the time period
s{1} = "sin 2πt";
f{1} = @(t)sin(2*pi*t);
T(1) = 1;

s{2} = "sin 10πt·sin 16πt";
f{2} = @(t)sin(10*pi*t).*sin(16*pi*t);
T(2) = 1;

s{3} = "sin 10πt/(2+sin 4πt)";
f{3}=@(t)sin(10*pi*t)./(2+sin(4*pi*t));
T(3) = 1;

s{4} = "(t+1) mod 2 -1";
f{4}=@(t)mod(t+1,2)-1;
T(4) = 2;

s{5} = "⌊t+1 mod 2⌋";
f{5}=@(t)floor(mod(t+1,2));
T(5) = 2;

s{6} = "sin(4πt) + 0.3 sin(10πt)";
f{6}=@(t)sin(2*pi*2*t) + 0.3*sin(2*pi*5*t);
T(6) = 2;


% #########################################################################################
% TASK 1 : sampling algorithm
% #########################################################################################

figure(1)

% sample frequency is given in Hz (samples per second)
sampleFrequency = 100;
% interval of time (in seconds) starting in 0 to be sampled 
timeinterval = 1;

[t, x] = sample(f{1}, timeinterval, sampleFrequency);
plot_curve(t, x, s{1}, 'time(s)', 'f(t)')


% #########################################################################################
% TASK 2 : Discrete Fourier Transform (DFT)
% #########################################################################################

figure(2)

% compute and plot frequency spectrum for the 4 functions and two frequencies (16Hz and 50Hz)
for test_function = 2 : 5

    % subwindow in the range 1..12
    subwindow = test_function - 1;

    % plot the original function and sample points
    subplot(3, 4, subwindow);
    % original function
    fplot(f{test_function}, [0,T(test_function)], 100);
    hold on;
    % sample points
    sampleFrequency = 16;
    [t, y] = sample(f{test_function}, T(test_function), sampleFrequency);
    plot_curve(t, y, s{test_function}, 'time(s)', 'f(t)', 'rx')
    sampleFrequency = 50;
    [t, y] = sample(f{test_function}, T(test_function), sampleFrequency);
    plot_curve(t, y, s{test_function}, 'time(s)', 'f(t)', 'kx')
    legend off;

    % plot frequency spectrum at 16Hz
    sampleFrequency = 16;
    [t, y] = sample(f{test_function}, T(test_function), sampleFrequency);
    [a, b] = dft(y, T(test_function), sampleFrequency);

    % subplot is indexed on the second row of the plot grid (so the +4)
    subplot(3, 4, subwindow + 4);
    plot_frequency_spectrum (a, b, s{test_function}, T(test_function))

    % plot frequency spectrum at 50Hz
    sampleFrequency = 50;
    [t, y] = sample(f{test_function}, T(test_function), sampleFrequency);
    [a, b] = dft(y, T(test_function), sampleFrequency);

    % subplot is indexed on the third row of the plot grid (so the +8)
    subplot(3, 4, subwindow + 8);
    plot_frequency_spectrum(a, b, s{test_function}, T(test_function))
end

% #########################################################################################
% TASK 3 : Cooley-Tukey FFT algorithm
% #########################################################################################

sampleFrequency = 64;

[t, x] = sample(f{6}, T(6), sampleFrequency);
freq = ctfft(x')';

subplot(2, 1, 1);
plot_curve(t, x, s{6}, 'time(s)', 'f(t)')
subplot(2, 1, 2);
plot_curve(1:numel(freq), abs(freq), s{6}, 'frequency (Hz)', 'amplitude')

% start_freq =  700 / (sampleFrequency / 2);


% #########################################################################################
% TASK 4 : Frequency analysis of a music signal
% #########################################################################################

[y, v_s] = audioread('beethoven_5th_sample.wav');
% audioinfo returns the number of samples and duration of the signal (among other data)
sampleinfo = audioinfo('beethoven_5th_sample.wav');

% resize sample as to match a power of 2
numsamples = 2^floor(log(sampleinfo.TotalSamples)/log(2));
y = y(1:numsamples, :);

freq = ctfft(y);

% filtering the signal
% order of the filter
n = 5;

cutoffFreq = 4000 / (v_s/2);

% signal processing package built-in functions
% generate a Butterworth filter. Default is a discrete space (Z) filter
% the cutoff frequency, for bandpass filters, wc is a two-element vector with w(1) < w(2)
[b, a] = butter(n, cutoffFreq, 'high');
out   = filter(b, a, y);

figure(4);

subplot(3, 1, 1)
plot(y);
axis([1, length(out), -0.4, 0.4])

subplot(3, 1, 2)
plot(out);
axis([1, length(out), -0.4, 0.4])

subplot(3, 1, 3)
plot(abs(freq));

audiowrite('beethoven_5th_sample_filtered.wav', y, v_s);


% #########################################################################################
% TASK 5 : Frequency analysis of a speech signal
% #########################################################################################

[y, v_s]   = audioread('my_voice.wav');
% audioinfo returns the number of samples and duration of the signal (among other data)
sampleinfo = audioinfo('my_voice.wav');

% resize sample as to match a power of 2
numsamples = 2^floor(log(sampleinfo.TotalSamples)/log(2));
y = y(1:numsamples, :);

freq = ctfft(y);

% Applying the filter to take out noise
n = 5;
cutoffFreq = 1500 / (v_s/2);

% signal processing package built-in functions
% generate a Butterworth filter. Default is a discrete space (Z) filter
% the cutoff frequency, for bandpass filters, wc is a two-element vector with w(1) < w(2)
[b, a] = butter(n, cutoffFreq, 'low');
out    = filter(b, a, y);

freqOut = ctfft(out);

figure(5);
subplot(4, 1, 1)
plot(y);
subplot(4, 1, 2)
plot(out);
subplot(4, 1, 3)
plot(abs(freq));
subplot(4, 1, 4)
plot(abs(freqOut));

audiowrite('my_voice_filtered.wav', y, v_s);
