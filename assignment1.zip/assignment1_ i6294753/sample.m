function [t, x] = sample(f, T, v_s)
% sample a given function for a time T and sample frequency v_s

    % number of samples
    N = T * v_s;
    % points in time
    t = (0 : N - 1) / N * T;
    % value of the function for those points
    x = f(t);

end