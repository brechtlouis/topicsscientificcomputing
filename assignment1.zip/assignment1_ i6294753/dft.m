function [a, b] = dft(x, T, vs)

    M = length(x);
    % samples to be obtained
    N = vs * T;

    % initial value to speed up updating of the coefficient vectors
    a = zeros(1, M);
    b = a;

    % times where the function is sampled
    n = 0 : 1 : N-1;

    % computing the Fourier coefficients 
    for i = 1 : M
        % sine and cosine functions
        fcos = arrayfun(@(x) cos(2 * pi * (i - 1) * x / N), n); 
        fsin = arrayfun(@(x) sin(2 * pi * (i - 1) * x / N), n);

        % updating the coefficients vectors
        a(1,i) = 2 / N * sum(x .* fcos);
        b(1,i) = 2 / N * sum(x .* fsin);
    end
end
