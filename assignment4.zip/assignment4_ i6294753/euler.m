function [ts, ys] = euler(f, t0f, y0)
    
    % initialize time steps and y values
    ts = t0f;
    ys = zeros(length(t0f), length(y0));
    ys(1, :) = y0;
    
    for timeId = 2 : numel(t0f)
        
        % previous time step and state vector
        t_i = t0f(timeId - 1);
        y_i = ys(timeId - 1, :);
        
        % size of the step
        h_i = t0f(timeId) - t_i;
        
        % update y_i+1 using Euler`s method
        y_next = transpose(y_i) + h_i * f(t_i, transpose(y_i));
        
        % add the computed values to the arrays
        ts(timeId) = t0f(timeId);
        ys(timeId, :) = transpose(y_next);
    end

end