clear all;

x0 = [15.0e6; 0.0];
v0 = [ 2.0e3; 4.0e3];

% built-in Matlab ODE function
[t, y] = ode23(@spaceship_system, 0:0.5:5, [x0; v0])

v0 = [3.9e3; 6e3]; 

[t1, y1] = ode23(@spaceship_system, 0:0.5:5, [x0; v0])


% calling the Euler function
t0f = t1;
[ts,ys] = euler(@spaceship_system, t0f, [x0; v0])

% calling odeRK4 for Runge-Kutta method
t0f = t1;
[ts2,ys2] = odeRK4(@spaceship_system, t0f, [x0; v0])
    
