function dy_dt = spaceship_system(t, y)
   
   % state of the Moon and the spaceship
   xs = y(1:2);
   vs = y(3:4);

   xm = moon_position(t);
   as = spaceship_acceleration(xm, xs); 

   dxs_dt = vs;
   dvs_dt = as;

   dy_dt = [dxs_dt; dvs_dt];

end
