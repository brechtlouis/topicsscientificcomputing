function xm = moon_position(t)
   
    % CONSTANTS
    % Earth-Moon distance in meters
    d_em = 400.5e6; 
    % Lunar month in seconds
    T_m = 27.3 * 24 * 3600; 
    % Initial angle in radians
    phi_0 = deg2rad(-61); 
    
    % Calculate the angle theta based on time t
    theta = 2 * pi * t / T_m;
    


    % Calculate the x and y coordinates of the moon
    x = d_em * cos(theta + phi_0);
    y = d_em * sin(theta + phi_0);
    
    % Create the output vector xm
    xm = [x; y];
    
end