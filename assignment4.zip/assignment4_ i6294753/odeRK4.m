function [ts, ys] = odeRK4(f, t0f, y0)

    % initialization
    ts = t0f;
    ys = zeros(numel(t0f), length(y0));
    ys(1, :) = y0;
    
    % Runge-Kutta
    for timeId = 2 : numel(t0f)
        
        t_i = t0f(timeId - 1);
        y_i = transpose(ys(timeId - 1, :));
        h_i = t0f(timeId) - t_i;
        
        k1 = h_i * f(t_i, y_i);
        k2 = h_i * f(t_i + h_i/2, y_i + 0.5 * k1);
        k3 = h_i * f(t_i + h_i/2, y_i + 0.5 * k2);
        k4 = h_i * f(t_i + h_i, y_i + k3);
        
        y_i1 = y_i + (1/6) * (k1 + 2*k2 + 2*k3 + k4);
        
        % add the computed values to the arrays
        ts(timeId) = t0f(timeId);
        ys(timeId, :) = y_i1;

    end
end
