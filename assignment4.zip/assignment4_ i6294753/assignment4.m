clear all

% closes all figures
close all

% CONSTANTS

% Earth`s mass in kg
me = 5.97e24;

% Moon`s mass in kg
mm = 7.35e22;  

% gravitational constant in N m2 / kg
G = 6.67e-11;

% Earth-Moon distance in meters
d_em = 400.5e6; 

% lunar month in seconds
T_m = 27.3 * 24 * 3600; 


% #########################################################################################
% Task 1 : Moon position
% #########################################################################################


figure(1);

% time of a complete lunar month
lunar_month_duration = 27.3 * 24 * 3600;
t = 1 : round(lunar_month_duration / 200) : lunar_month_duration;

% trajectory of the Moon
x = moon_position(t);
plot(x(1,:), x(2,:), 'b.');
xlabel('x position (m)')
ylabel('y position (m)')
axis square


% #########################################################################################
% Task 6 : Spaceship back into Moon orbit
% #########################################################################################

timestep     = 100;
timeStepPlot = 10;

%         Earth    scape    slow  approach    back
%         orbit    Earth    down  the Moon    home
phase = [ 15e6,     NaN,     NaN,     NaN,     NaN;     % initial point
            1e6,     NaN,     NaN,     NaN,     NaN;   
            2e3,     2.2,    0.21,  0.55,     0.7; % speed
            4e3,     NaN,     NaN,     NaN,     NaN;
            9900,    5200,   68000,  295000,  100000 ];  % duration

phaseLast = size(phase, 2);
phaseLast = 5;


% compute the trajectory of the spaceship
T = [];
X = [];
startTime = 0;
for phaseId = 1 : phaseLast

    % determine starting position and speed
    if ~isnan(phase(1, phaseId))
        startPoint = phase(1 : 2, phaseId);
    else
        startPoint = transpose(X(end, 1 : 2));
    end
    if ~isnan(phase(4, phaseId))
        % parameter is speed value
        startSpeed = phase(3 : 4, phaseId);
    else
        % parameter is coeficient for the current speed value
        startSpeed = phase(3, phaseId) * transpose(X(end, 3 : 4));
    end

    fprintf('Phase %d\n', phaseId);
    fprintf('  position %d, %d\n', round(startPoint(1)), round(startPoint(2)));
    fprintf('  speed    %d, %d\n', round(startSpeed(1)), round(startSpeed(2)));
    fprintf('  duration %d\n',     phase(5, phaseId));

    % compute trajectory
    [T1, X1] = odeRK4(@spaceship_system, startTime : timestep: sum(phase(5, 1 : phaseId)), [startPoint; startSpeed]);
    T = [T, T1];
    X = [X; X1];

    % starting time for next phase
    startTime = sum(phase(5, 1 : phaseId)) + timestep;
end

overalltime = (size(T, 2) - 1) * timestep;

xm = transpose(moon_position(0 : timestep : overalltime));


% plot the trajectory of the spaceship
figure(2);
plot(0,0,'b.')
hold on

points1 = animatedline;
points2 = animatedline;
for i = 1 : timeStepPlot : length(xm)
    addpoints(points1, xm(i,1), xm(i,2))
    addpoints(points2, X(i,1), X(i,2))
    drawnow limitrate
end

xlabel('x-position(m)')
ylabel('y-position(m)')

title(sprintf('Moon approach speed = %f', phase(3, 4)))
axis square

