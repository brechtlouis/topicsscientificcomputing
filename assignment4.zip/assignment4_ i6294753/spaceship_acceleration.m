function as = spaceship_acceleration(xm, xs)
   
    % CONSTANTS
    % gravitational constant 
    G = 6.673e-11; 
    % mass of the Earth
    me = 5.97e24;
    % mass of the Moon
    mm = 7.35e22;

    % Calculate the acceleration of the spaceship
    as = -G * ((me * xs / (sqrt(xs(1)^2 + xs(2)^2)).^3) + (mm / (sqrt((xs(1) - xm(1))^2 + (xs(2) - xm(2))^2)).^3) * (xs - xm));

end
