v=[1 2 3 4 5 6]

averagevalue2(v)
mean(v)

function avg = averagevalue2(v)
    vsum=0;
    for n=1:length(v)
        vsum=vsum+v(n);
    end
    avg=vsum/length(v);
end

