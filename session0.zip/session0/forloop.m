x=ones(1,10)

for n=2:6
    x(n)=2*n(n-1)
end


v=[1 2 3 4 5]
for n
    vsum(n)=v(n)
end