v=[1 2 3 4 5]
vsum=0;

function c = sum2values(a,b)
%SUM2VALUES Summary of this function goes here
%   Detailed explanation goes here
c=a+b
end