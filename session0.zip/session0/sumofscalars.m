a=1;
b=2;


%first create a vector
c=[a b];

%then do the function sum
d=sum([a b])