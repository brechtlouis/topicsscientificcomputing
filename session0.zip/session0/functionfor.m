v=[1 2 3 4 5]
vsum=0;

function c = sum2values(a,b)
    for n=1:length(v)
        vsum=vsum+v(n)
    end
end