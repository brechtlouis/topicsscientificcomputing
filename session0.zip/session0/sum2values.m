

function c = sum2values(a,b)
%SUM2VALUES Summary of this function goes here
%   Detailed explanation goes here
c=a+b
end


function d =diff2values(a,b)
c=a-b
end


