function labels = myKNN(train_data, test_data, Nbr)
% K-nearest neighbors classifier

    numberTestStars = size(test_data, 1);
    
    labels = zeros(1, numberTestStars);

    for testStarIndex = 1 : numberTestStars
        
        % classes of the Nbr closest neighbors
        % 1- distances from the test star to all the training stars
        distances = squared_distances(train_data(:, 1:2), test_data(testStarIndex, :));
        % 2- sort distances from closest to farthest
        [dist, star] = sort(distances);
        % 3- take the most voted class
        labels(testStarIndex) = mode(train_data(star(1 : Nbr), 3));

    end

end