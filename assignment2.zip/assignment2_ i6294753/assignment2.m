clear all

% closes all figures
close all

pointColor = 'kcgmbr';

numberClusters = 6;
maxIter = 8;

plot_regions = false;

% #########################################################################################
% TASK 1 : data loading
% #########################################################################################

% read dataset
points = table2array(readtable('StarTypeDataset'));

temperature = points(:,1);
magnitude   = points(:,2);

fprintf("Average temperature: %f\n", mean(temperature));
fprintf("Average absolute magnitude: %f\n", mean(abs(magnitude)));

figure(1);
plot_data(temperature, magnitude, [], 'b+');

fprintf("Press a key to continue...\n");
pause

% #########################################################################################
% TASK 2 : squared distances
% ########################################################################################

distances = squared_distances(points, mean(points));

% #########################################################################################
% TASK 3 : k-means algorithm
% #########################################################################################

fprintf("\n\nClustering by the K-means method...\n");
maxIter = 8;
numberClusters = 6;
[assignments, centers] = myKmeans(points, numberClusters, maxIter);

% #########################################################################################
% TASK 4 : plot points, clusters and assignments, determine clustering quality
% #########################################################################################

% plot all the stars, cluster means, and cluster assignments
plot_clusters(points, centers, assignments, 2)

% quality of the clustering
squareDistances = distances_points_centers(points, centers);
overallDistance = 0;
for pointIndex = 1 : size(points,1)
    overallDistance = overallDistance + squareDistances(pointIndex, assignments(pointIndex));
end
fprintf("Overall squared errors: %f\n", overallDistance);

fprintf("Press a key to continue...\n");
pause


% #########################################################################################
% TASKS 5-6 : KNN algorithm
% #########################################################################################

fprintf("\n\nClassification by the K-NN method...\n");

% assign arbitrary classes to training points with the K-means method
[classes, centers] = myKmeans(points, numberClusters, maxIter);

train_data = [points, transpose(classes)];
test_data  = [0.75 -0.1; -0.9 -0.1; 0.6 0.08; -1.25 -0.2];

Nbr = 2;

labels = myKNN(train_data, test_data, Nbr);

% #########################################################################################
% TASK 6 : plot + questions
% #########################################################################################
% plot training_data
plot_clusters(points, centers, classes, 3);
% plot test_data
for testIndex = 1 : size(test_data, 1);
    plot(test_data(testIndex, 1), test_data(testIndex, 2), [pointColor(labels(testIndex)) 's']);
end

fprintf("Press a key to continue...\n");
pause

% #########################################################################################
% TASK 7 : decision boundary algorithm
% #########################################################################################

% draw classes with different colors so boundaries can be seen

if plot_regions

    % distance between points
    increment = 0.025;

    % range of the points coordinates
    min_value = floor(min(points));
    max_value = ceil(max(points));

    % coordinates of a grid of points covering all the area
    gridPoints = zeros(prod((max_value - min_value) / increment), 2);
    cont = 0;
    for idx = min_value(1) : increment : max_value(1)
        for idy = min_value(2) : increment : max_value(2)
            cont = cont + 1;
            gridPoints(cont, :) = [idx, idy];
        end
    end

    % classify each point
    labels = myKNN(train_data, gridPoints, Nbr);

    % plot grid
    figure(4);
    hold on
    for testIndex = 1 : size(gridPoints, 1);
        plot(gridPoints(testIndex, 1), gridPoints(testIndex, 2), [pointColor(labels(testIndex)) '.']);
        drawnow
    end
end
