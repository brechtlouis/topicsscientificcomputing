function centers = random_centers(points, k, method)
% Determine a good initiatilization of centers

    switch method
        case 'mean_point'
            for centerIndex = 1 : k
                centers(centerIndex, :) = mean(points) + 0.001 * rand(1, 2);
            end
        
        case 'min_distance'
            fprintf("Searching for good initial centers...\n");

            % range of the points coordinates
            min_value = min(points);
            max_value = max(points);

            for iteration = 1 : 100

                % random centers in the points range
                rand_centers = (max_value - min_value) .* rand(k, 2) + min_value;

                % check if assigned clusters distributed better
                current_distance = sum(sum(distances_points_centers(points, rand_centers)));
                if ~exist('max_distance', 'var') || current_distance < min_distance
                    centers = rand_centers;
                    min_distance = current_distance;
                end
            end

        case 'min_std'

            fprintf("Searching for good initial centers...\n");
            % range of the points coordinates
            min_value = min(points);
            max_value = max(points);

            for iteration = 1 : 100

                % random centers in the points range
                rand_centers = (max_value - min_value) .* rand(k, 2) + min_value;

                % assign a cluster to each point
                assignments = assign_cluster(points, rand_centers);

                % count how many points in each cluster
                for clusterIndex = 1 : k
                    pointsincluster(clusterIndex) = sum(assignments == clusterIndex);
                end

                % check if assigned clusters distributed better
                current_std = std(pointsincluster);
                if iteration == 1 || current_std < min_std
                    centers = rand_centers;
                    min_std = current_std;
                end
            end

        otherwise
            error('Bad method for centers initialization...')
    end

end