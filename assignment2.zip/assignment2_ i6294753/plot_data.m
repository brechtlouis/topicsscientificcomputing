function plot_data(temperature, magnitude, centers, symbol)

    % character for the group/class
    symbolChar2 = 'o';

    % determine symbolColor
    if ~exist('symbol', 'var')
        % default color of the character
        symbolColor = 'r';
        % character for the point
        symbolChar1 = '+';
    else
        if numel(symbol) == 1
            % only the color is provided

            % default character for the points
            symbolColor = symbol;
            symbolChar1 = '+';
        else
            symbolColor = symbol(1);
            symbolChar1 = symbol(2);
        end
    end

    % plot each data point
    plot(temperature, magnitude, [symbolColor symbolChar1]);
    xlabel('temperature');
    ylabel('magnitude');

    % plot centers
    if exist('centers', 'var') && any(centers)
        plot(centers(:,1), centers(:,2), [symbolColor symbolChar2])
    end

end