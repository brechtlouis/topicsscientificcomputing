function r = distances_points_centers(points, centers)

    % distances from all points to all centers
    for cluster = 1 : size(centers, 1)
        r(:, cluster) = squared_distances(points, centers(cluster, :));
    end
end