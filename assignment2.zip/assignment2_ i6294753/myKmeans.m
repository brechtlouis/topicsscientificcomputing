function [assignments, centers] = myKmeans(points, k, maxIter)

%    centers = [-1 0; -1 -0.6; -0.75 0.8; 0 0; 0.5 0; 0.5 0.3];

    % allows step-by-step visualization of the assignments in each iteration
    stepbystep = false;

    centers = random_centers(points, k, 'mean_point');

%    plot_data(points(:,1), points(:,2), centers, 'b+');

    numberPoints = size(points, 1);
    assignments = NaN(1, numberPoints);
    r = zeros(numberPoints, k);


    % Iterate ’maxIter’ times
    for iteration = 1 : maxIter

        % assign a cluster to each point
        assignments = assign_cluster(points, centers);
        
        fprintf('Iteration %d...\n', iteration)
        if stepbystep
            plot_clusters(points, centers, assignments, 1)
            pause
        end

        % new center as the mean point
        old_centers = centers;
        for clusterIndex = 1 : k
            pointIndex = find(assignments == clusterIndex);
            if any(pointIndex)
                centers(clusterIndex, :) = mean(points(pointIndex, :));
            end
        end

        % determine stop condition
        difference = 0;
        for clusterIndex = 1 : k
            difference = difference + sum(abs(centers(clusterIndex, :) - old_centers(clusterIndex, :)));
        end
        if difference == 0
            break
        end

    end
end