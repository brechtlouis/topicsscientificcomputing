function plot_clusters(points, centers, assignments, figureIndex)

    if exist('figureIndex', 'var')
        figure(figureIndex);
    end

    clf
    hold on

    % plot the resulting clusters coloring the points
    pointColor = 'kcgmbr';
    for centerIndex = 1 : size(centers, 1)
        pointIndex = find(assignments == centerIndex);
        plot_data(points(pointIndex, 1), points(pointIndex,2), centers(centerIndex, :), pointColor(centerIndex));
    end
end
