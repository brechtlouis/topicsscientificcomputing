function distance = squared_distances(U, v)
% Distances between 2D point v and 2D points in U
    
    distances = zeros(size(U,2), 1);
    n = length(U);
    for i = 1 : n
        distance(i) = sum((U(i,:) - v).^2, 2);
    end

end