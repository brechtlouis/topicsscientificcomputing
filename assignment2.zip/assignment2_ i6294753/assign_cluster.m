function assignments = assign_cluster(points, centers)

    r = distances_points_centers(points, centers);

    % assign each pattern to the cluster with the closest center
    for n = 1 : size(points, 1)
        [values, assignments(n)] = min(r(n,:));
    end
end