clear all

% closes all figures
close all


% #########################################################################################
% Task 1 : Regression on Electro Motor dataset
% #########################################################################################

% read dataset
data = dlmread('DatasetElectricMotor.csv', ',', 1,0);

myRegression(data);


% #########################################################################################
% Task 4 : myPCA of Mice Protein Expression
% #########################################################################################


myPCA('MiceProteinExpressionDataset');



