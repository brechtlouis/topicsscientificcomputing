function myRegression(data)

displayPlots = true;

% #########################################################################################
% Task 1 : Regression on Electro Motor dataset
% #########################################################################################

% dependent variable
targetVariable = data(:, 7);

% predict measured q-current at k + 1

% first case: continuous independent variables only
independentVariables = data(:, 1:3);
% model fitting
x = independentVariables \ targetVariable;
% variable inference
predictedVariable = independentVariables * x;
fprintf('Overall error with continuous variables: %8.2f\n', sum(abs(targetVariable - predictedVariable)))

% second case: discrete independent variables only
independentVariables = data(:, 4:5);
% model fitting
x = independentVariables \ targetVariable;
% variable inference
predictedVariable = independentVariables * x;
fprintf('Overall error with discrete variables:   %8.2f\n', sum(abs(targetVariable - predictedVariable)))

% third case: all independent variables
independentVariables = data(:, 1:5);
% model fitting
x = independentVariables \ targetVariable;
% variable inference
predictedVariable = independentVariables * x;
fprintf('Overall error with all variables:        %8.2f\n', sum(abs(targetVariable - predictedVariable)))


if displayPlots
    figure(1)
    rangetodisplay = 1:100;

    subplot(211)
    plot(targetVariable(rangetodisplay), 'b-')
    hold on
    plot(predictedVariable(rangetodisplay), 'r-')
    axis([1 100 0 300])
    ylabel('real and predicted curves')

    subplot(212)
    bar(targetVariable(rangetodisplay) - predictedVariable(rangetodisplay))
    axis([1 100 -100 100])
    ylabel('error')

    % iterate through independent variables and create scatter plots
    for i = 1 : 5

        independentVariable = data(:, i);

        % plot values
        figure(i + 1);
        scatter(independentVariable, targetVariable, 50, 'k', '.');
        % label axes
        xlabel(['X', num2str(i)]);
        ylabel('measured q-current at k + 1');
    end
end

% #########################################################################################
% Task 2 : Split data into training and testing sets
% #########################################################################################

% split dataset into training and testing sets
numSamples  = size(data, 1);
numTraining = ceil(0.8 * numSamples);
numTesting  = numSamples - numTraining;
randomIndex = randperm(numSamples);
trainingSet = data(randomIndex(1 : numTraining), :);
testingSet  = data(randomIndex(numTraining + 1 : end), :);
fprintf('\nDataset splited into %d training and %d test data\n', numTraining, numTesting);

variableNames = {'current in d-coordinate (k)', 'current in q-coordinate (k)', 'rotational angle (k)', 'elementary vector (k)', 'elementary vector (k-1)', 'current in d-coordinate (k+1)', 'current in q-coordinate (k+1)'};


% iterate through independent variables and create scatter plots
targetVariable = trainingSet(:, 7);

for i = 1 : 5

    independentTrainingVariable = trainingSet(:, i);
    independentTestingVariable  = testingSet(:, i);

    % model fitting
    x = independentTrainingVariable \ targetVariable;
    % variable inference
    predictedTrainingVariable = independentTrainingVariable * x;
    predictedVariable = independentTestingVariable * x;

    if displayPlots
        % plot values
        figure(6 + i)
        hold on

        subplot(411)
        plot(independentTrainingVariable, 'r-');
        axis([1 numTraining min(independentTrainingVariable) max(independentTrainingVariable)])
        title(variableNames{i})
        ylabel('training');

        subplot(412)
        plot(independentTestingVariable, 'b-');
        axis([1 numTesting min(independentTestingVariable) max(independentTestingVariable)])
        ylabel('testing');

        subplot(413)
        plot(predictedTrainingVariable, 'k-');
        axis([1 size(predictedTrainingVariable, 1) min(predictedTrainingVariable) max(predictedTrainingVariable)])
        title(variableNames{7})
        ylabel('predicted');

        subplot(414)
        plot(predictedVariable, 'g-');
        axis([1 numTesting min(predictedVariable) max(predictedVariable)])
        title(variableNames{7})
        ylabel('predicted');    end

    % MSE
    mse = sqrt(sum((predictedVariable - independentTestingVariable).^2));
    fprintf('MSE for %s: %8.2f\n', variableNames{i}, mse)

end

% #########################################################################################
% Task 3 : Regression for higher order polynomials from 1 to 10
% #########################################################################################

% regression for higher order polynomials

bestIndependentVariableTraining = trainingSet(:, 2);
targetVariable  = trainingSet(:, 7);
testingVariable = testingSet(:, 7);
for N = 1 : 10
    [P, S, MU] = polyfit(bestIndependentVariableTraining, targetVariable, N);
    predictedVariable = polyval(P, testingVariable, S, MU);
    mse = sqrt(sum((predictedVariable - testingVariable).^2));
    fprintf('MSE for %s with order %d: %8.2f\n', variableNames{2}, N, mse);
    
end
