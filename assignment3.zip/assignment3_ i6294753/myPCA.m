function myPCA(datasetfilename)

% read dataset
data = dlmread([datasetfilename, '.csv'], ',', 1,0);

% zero-centering the data

normalizedData = (data - mean(data)) ./ (max(data) - min(data));
% normalizedData = (data - mean(data)) ./ std(data);

% covariance matrix
covarianceMatrix = cov(normalizedData);

% eigenvectors and eigenvalues
[V, D] = eig(covarianceMatrix);
% get eigenvalues (they are already sorted)
D = transpose(diag(D));

% plot projected data onto the two main components
figure(12)
plot(data * V(:,end), data * V(:,end-1), '.')

% selection of principal components according to variance
varianceExplained = 100 * D ./ sum(D);

varianceExplainedpct = cumsum(varianceExplained(end:-1:1));
fprintf('1st and 2nd components explain %2.2f%% of the variance.\n', varianceExplainedpct(1,2));
cumulativeVariance = find(varianceExplainedpct > 98);
fprintf('Components to explain 98%% variance: %d\n', cumulativeVariance(1))

% plot contribution of each component and how they add up to 98%
figure(13)
bar(varianceExplainedpct)
hold on
line([0 numel(varianceExplained)], [98 98])

